package com.mahaboard.result;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AdminLoginActivity extends AppCompatActivity {

    private EditText etAdminId, etPassword;
    private SharedPreferences prefs;
    private boolean pwdVisible = false;

    // ─── Default Admin Credentials (pre-configured) ───
    private static final String DEFAULT_ADMIN_ID  = "daradevaibhav293@gmail.com";
    private static final String DEFAULT_ADMIN_PWD = "Vai123@#$";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        prefs = getSharedPreferences("AdminPrefs", MODE_PRIVATE);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Admin Login");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        etAdminId  = findViewById(R.id.etAdminId);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin    = findViewById(R.id.btnLogin);
        ImageView ivToggle = findViewById(R.id.ivTogglePwd);

        // Toggle password visibility
        ivToggle.setOnClickListener(v -> {
            pwdVisible = !pwdVisible;
            if (pwdVisible) {
                etPassword.setTransformationMethod(null);
                ivToggle.setImageResource(android.R.drawable.ic_menu_view);
            } else {
                etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                ivToggle.setImageResource(android.R.drawable.ic_secure);
            }
            etPassword.setSelection(etPassword.getText().length());
        });

        btnLogin.setOnClickListener(v -> {
            String enteredId  = etAdminId.getText().toString().trim();
            String enteredPwd = etPassword.getText().toString().trim();

            // Get saved credentials (defaults: pre-configured)
            String savedId  = prefs.getString("admin_id",  DEFAULT_ADMIN_ID);
            String savedPwd = prefs.getString("admin_password", DEFAULT_ADMIN_PWD);

            if (enteredId.equals(savedId) && enteredPwd.equals(savedPwd)) {
                startActivity(new Intent(this, AdminPanelActivity.class));
                finish();
            } else {
                Toast.makeText(this, "❌ चुकीचा ID किंवा Password!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
