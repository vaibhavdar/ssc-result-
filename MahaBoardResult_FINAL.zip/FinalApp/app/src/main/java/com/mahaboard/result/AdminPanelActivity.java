package com.mahaboard.result;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AdminPanelActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    // URL Fields
    private EditText etUrlSsc, etUrlHsc, etUrlBoard;

    // Unity Ads Fields
    private EditText etGameId, etBannerPid, etInterstitialPid, etRewardedPid;

    // Toggles
    private Switch switchAdsEnabled, switchTestMode;

    // ─── Pre-configured Unity Ads IDs ───
    private static final String DEFAULT_GAME_ID        = "6099427";
    private static final String DEFAULT_BANNER_PID     = "Banner_Android";
    private static final String DEFAULT_INTERSTITIAL_PID = "Interstitial_Android";
    private static final String DEFAULT_REWARDED_PID   = "Rewarded_Android";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        prefs  = getSharedPreferences("AdminPrefs", MODE_PRIVATE);
        editor = prefs.edit();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("🔐 Admin Panel");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Show currently logged-in admin
        TextView tvLoggedIn = findViewById(R.id.tvLoggedIn);
        if (tvLoggedIn != null) {
            String adminId = prefs.getString("admin_id", "daradevaibhav293@gmail.com");
            tvLoggedIn.setText("✅ Logged in: " + adminId);
        }

        bindViews();
        loadSavedValues();
        setupButtons();
    }

    private void bindViews() {
        etUrlSsc           = findViewById(R.id.etUrlSsc);
        etUrlHsc           = findViewById(R.id.etUrlHsc);
        etUrlBoard         = findViewById(R.id.etUrlBoard);
        etGameId           = findViewById(R.id.etGameId);
        etBannerPid        = findViewById(R.id.etBannerPlacement);
        etInterstitialPid  = findViewById(R.id.etInterstitialPlacement);
        etRewardedPid      = findViewById(R.id.etRewardedPlacement);
        switchAdsEnabled   = findViewById(R.id.switchAdsEnabled);
        switchTestMode     = findViewById(R.id.switchTestMode);
    }

    private void loadSavedValues() {
        // URLs
        etUrlSsc.setText(prefs.getString("url_ssc",   "https://sscresult.mkcl.org"));
        etUrlHsc.setText(prefs.getString("url_hsc",   "https://hscresult.mkcl.org"));
        etUrlBoard.setText(prefs.getString("url_board","https://mahahsscboard.in"));

        // Unity Ads — defaults are pre-configured
        etGameId.setText(prefs.getString("unity_game_id",             DEFAULT_GAME_ID));
        etBannerPid.setText(prefs.getString("banner_placement_id",    DEFAULT_BANNER_PID));
        etInterstitialPid.setText(prefs.getString("interstitial_placement_id", DEFAULT_INTERSTITIAL_PID));
        etRewardedPid.setText(prefs.getString("rewarded_placement_id", DEFAULT_REWARDED_PID));

        // Toggles
        switchAdsEnabled.setChecked(prefs.getBoolean("ads_enabled", true));
        switchTestMode.setChecked(prefs.getBoolean("test_mode", false));
    }

    private void setupButtons() {
        // ── Save URLs ──
        Button btnSaveUrls = findViewById(R.id.btnSaveUrls);
        btnSaveUrls.setOnClickListener(v -> {
            String ssc   = etUrlSsc.getText().toString().trim();
            String hsc   = etUrlHsc.getText().toString().trim();
            String board = etUrlBoard.getText().toString().trim();

            if (ssc.isEmpty() || hsc.isEmpty() || board.isEmpty()) {
                Toast.makeText(this, "⚠️ सर्व URLs भरा!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!ssc.startsWith("http") || !hsc.startsWith("http") || !board.startsWith("http")) {
                Toast.makeText(this, "⚠️ Valid URLs टाका (https:// ने सुरु करा)", Toast.LENGTH_SHORT).show();
                return;
            }

            editor.putString("url_ssc",   ssc);
            editor.putString("url_hsc",   hsc);
            editor.putString("url_board", board);
            editor.apply();
            Toast.makeText(this, "✅ URLs Save झाले!", Toast.LENGTH_SHORT).show();
        });

        // ── Save Ads Settings ──
        Button btnSaveAds = findViewById(R.id.btnSaveAds);
        btnSaveAds.setOnClickListener(v -> {
            String gameId = etGameId.getText().toString().trim();
            if (gameId.isEmpty()) {
                Toast.makeText(this, "⚠️ Unity Game ID टाका!", Toast.LENGTH_SHORT).show();
                return;
            }
            editor.putString("unity_game_id",             gameId);
            editor.putString("banner_placement_id",       etBannerPid.getText().toString().trim());
            editor.putString("interstitial_placement_id", etInterstitialPid.getText().toString().trim());
            editor.putString("rewarded_placement_id",     etRewardedPid.getText().toString().trim());
            editor.putBoolean("ads_enabled",              switchAdsEnabled.isChecked());
            editor.putBoolean("test_mode",                switchTestMode.isChecked());
            editor.apply();
            Toast.makeText(this, "✅ Ads Settings Save झाले! App Restart करा.", Toast.LENGTH_LONG).show();
        });

        // ── Change Admin Password ──
        Button btnChangePwd = findViewById(R.id.btnChangePassword);
        btnChangePwd.setOnClickListener(v -> {
            EditText inputOld = new EditText(this);
            inputOld.setHint("जुना Password");
            inputOld.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

            EditText inputNew = new EditText(this);
            inputNew.setHint("नवीन Password");
            inputNew.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

            android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
            layout.setOrientation(android.widget.LinearLayout.VERTICAL);
            layout.setPadding(48, 16, 48, 0);
            layout.addView(inputOld);
            layout.addView(inputNew);

            new AlertDialog.Builder(this)
                .setTitle("🔑 Password बदला")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String oldPwd = inputOld.getText().toString().trim();
                    String newPwd = inputNew.getText().toString().trim();
                    String currentPwd = prefs.getString("admin_password", "Vai123@#$");

                    if (!oldPwd.equals(currentPwd)) {
                        Toast.makeText(this, "❌ जुना Password चुकीचा!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (newPwd.length() < 6) {
                        Toast.makeText(this, "⚠️ Password किमान 6 अक्षरांचा असावा!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    editor.putString("admin_password", newPwd).apply();
                    Toast.makeText(this, "✅ Password बदलला!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("रद्द करा", null).show();
        });

        // ── Change Admin ID ──
        Button btnChangeId = findViewById(R.id.btnChangeId);
        btnChangeId.setOnClickListener(v -> {
            EditText input = new EditText(this);
            input.setHint("नवीन Admin ID / Email");
            input.setText(prefs.getString("admin_id", "daradevaibhav293@gmail.com"));
            android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
            layout.setPadding(48, 16, 48, 0);
            layout.addView(input);

            new AlertDialog.Builder(this)
                .setTitle("👤 Admin ID बदला")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    String id = input.getText().toString().trim();
                    if (!id.isEmpty()) {
                        editor.putString("admin_id", id).apply();
                        Toast.makeText(this, "✅ Admin ID बदलला!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("रद्द करा", null).show();
        });

        // ── Reset to Defaults ──
        Button btnReset = findViewById(R.id.btnReset);
        if (btnReset != null) {
            btnReset.setOnClickListener(v -> {
                new AlertDialog.Builder(this)
                    .setTitle("⚠️ Default वर Reset करा?")
                    .setMessage("सर्व Settings Default वर जातील. नक्की करायचे का?")
                    .setPositiveButton("हो, Reset करा", (d, w) -> {
                        editor.clear().apply();
                        loadSavedValues();
                        Toast.makeText(this, "✅ Default Settings Restore झाले!", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("नाही", null).show();
            });
        }

        // ── Logout ──
        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> finish());
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
