# 🎓 Maharashtra Board Result App — Final Version

## ✅ Pre-configured Settings
| Setting | Value |
|---------|-------|
| Admin ID | daradevaibhav293@gmail.com |
| Admin Password | Vai123@#$ |
| Unity Game ID | 6099427 |
| Rewarded Ad | Rewarded_Android |
| Interstitial Ad | Interstitial_Android |
| Banner Ad | Banner_Android |

## 📱 App Features
- **10वी (SSC) Result** — WebView with MKCL official site
- **12वी (HSC) Result** — WebView with MKCL official site  
- **Maharashtra Board** — Official board website
- **Admin Panel** (Password Protected inside the app)

## 💰 Ads System (Unity Ads)
1. **Banner Ad** — Always visible at bottom (every screen)
2. **Rewarded Ad** — Shows when app opens (maximum revenue)
3. **Interstitial Ad** — Shows on every tab switch + on exit

## 🔐 Admin Panel Access
- Go to app → Menu (3 dots top right) → ⚙ Admin
- Enter your credentials to login
- Change URLs, Ads settings, Password anytime

## 🏗️ Build Instructions
1. Open in Android Studio
2. Build → Generate Signed APK
3. Upload to Google Play Store

## 📋 Requirements
- Android Studio Hedgehog or newer
- minSdk: 21 (Android 5.0+)
- targetSdk: 34
